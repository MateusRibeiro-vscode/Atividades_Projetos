package Exemplo;

abstract  class Funcionario {
    //protect ajuda que so pode ser acesado pelo mesmo packate
    protected String nome;

    public Funcionario (String nome){
        this.nome=nome;
    }
    public void mostrarNome() {
        System.out.println("Funcionário: " + nome);
    }
    public abstract double calcularSalario();

}

class FuncionarioCLT extends Funcionario {
    private double salariobasic;
    public FuncionarioCLT(String nome,double salariobasic) {
        super(nome);
        this.salariobasic=salariobasic;
    }



    @Override
    public double calcularSalario() {
        return salariobasic;
    }
}

 class Emprime{
     static void main(String[] args) {
         Funcionario f = new FuncionarioCLT("enzo",2147483647);

         f.mostrarNome();
         System.out.println("Salário: R$ " + f.calcularSalario());
     }
}
