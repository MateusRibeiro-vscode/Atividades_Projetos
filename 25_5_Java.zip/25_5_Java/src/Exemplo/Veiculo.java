package Exemplo;

sealed public class Veiculo permits Carro , Moto {
    public void mover() {
        System.out.println("O veículo está em movimento.");
}}
 final class Carro extends Veiculo {
        public void abrirPortaMalas() {
        System.out.println("Porta-malas aberto.");
    }}
final class Moto extends Veiculo {
    public void empinar() {
        System.out.println("A moto empinou com segurança no exemplo didático.");
    }
}
class Mensagemm {
    public static void main(String[] args) {
        Veiculo v = new Veiculo();
        move(v);
        Carro c = new Carro();

        move(c);

        Moto m = new Moto();

        move(m);

    }
    public static void move(Veiculo a){

        a.mover();

        if(a instanceof Moto){
            ((Moto) a).empinar();
        }
        else if(a instanceof Carro){
            ((Carro) a).abrirPortaMalas();
        }
    }
}