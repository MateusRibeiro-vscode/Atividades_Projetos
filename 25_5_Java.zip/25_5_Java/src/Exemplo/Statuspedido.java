package Exemplo;

public enum Statuspedido {
    /**
     * o enum e basicamente para pessoa nao
     * ultilizar varios nome numa class exemplo
     * Pendente ,pendente ,pen
     * esse codigo nao tem como pegar com definiça
     * o basica enta poristo ultilizamos enum
     **/
    PEMDENTE(4),
    PROCESSANDO(3),
    ENVIADO(20),
    ENTREGUE(10);
    public int relacao;
    Statuspedido(int relacao) {
      this.relacao=relacao;
    }

}
class EnumDemo {
    public static void main(String[] args) {
        Statuspedido enviado = Statuspedido.ENVIADO;
        System.out.println(enviado.relacao +" ou "+ enviado);

    }}
