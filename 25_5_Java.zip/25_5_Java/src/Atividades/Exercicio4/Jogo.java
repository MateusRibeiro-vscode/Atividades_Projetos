package Atividades.Exercicio4;

public class Jogo {
    private String nome;

    public Jogo(String nome) {
        this.nome = nome;
    }

    class jogador{
     private  int vidas;

        public jogador(int vidas) {
            this.vidas = vidas;
        }
   public void men(){
       System.out.println("nome do jogo "+nome);
       System.out.println("uqntidade de vida" +vidas);
   }
    }


}

class ExJOgo {
    static void main(String[] args) {


        Jogo j = new Jogo(Input.st(("qual o nome do jogo")));
        Jogo.jogador ld = j.new jogador(Input.i("qual a sua uqntidade de vida"));
        ld.men();
    }
}