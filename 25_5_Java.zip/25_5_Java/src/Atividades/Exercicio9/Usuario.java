package Atividades.Exercicio9;

public record Usuario(String login, String email) {
    public  Usuario{

    }
}
  class ExeUsuario{
      static void main(String[] args) {
          Usuario u = new Usuario(Input.st("qual e o nome do umsuario"),Input.st("qual o seu email  "));
          System.out.println("o nome do umsuario e "+u.login());
          System.out.println("o seu email e "+u.email());
          System.out.println(u);

      }
}
