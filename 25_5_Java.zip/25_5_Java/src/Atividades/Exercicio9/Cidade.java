package Atividades.Exercicio9;

public record Cidade(String nome, String estado) {

        public Cidade{

        }
    }
    class exCida{
        static void main(String[] args) {
           Cidade c = new Cidade(Input.st("qual a cidade "),Input.st("qual o estado"));
            System.out.println("nome " + c.nome());
            System.out.println("estado "+c .estado());
            System.out.println(c);
        }
    }

