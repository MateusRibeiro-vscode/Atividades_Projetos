package Atividades.Exercicio9;

public record Cordenadas(int x, int y) {
    public Cordenadas{

    }
}
class Excorde{
    static Cordenadas c = new Cordenadas(Input.i("qual a posiçao x"),Input.i("qual a posicao y"));

    static void main(String[] args) {
        System.out.println("a cordenada x e "+c.x());
        System.out.println("a cordenada y e "+c.y());
        System.out.println(c);
    }
}
