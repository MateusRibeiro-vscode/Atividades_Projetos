package Atividades.Exercicio2;

import java.util.Scanner;

public abstract  class Funcionario {
    abstract double calcularBonus(double s);
}
 class Outrofncionario extends Funcionario{

     @Override
     double calcularBonus(double s) {
         return (s+(s*70/100));
     }
 }
 class exoutrofuncionario{
    public static void main(String[] args) {
         Outrofncionario o = new Outrofncionario();
         System.out.println("seu salario");
         Scanner s = new Scanner(System.in);

        System.out.println(o.calcularBonus(s.nextDouble()));
     }
 }
