package Atividades.Exercicio7;

public class Biblioteca {
    static class Categoria{
        public void me(){
            System.out.println("categoria");
        }
    }

}
class exmenBibio{
    static void main(String[] args) {
        Biblioteca.Categoria c = new Biblioteca.Categoria();
        c.me();
    }
}
