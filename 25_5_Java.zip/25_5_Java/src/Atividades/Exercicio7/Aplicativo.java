package Atividades.Exercicio7;
public class Aplicativo {
     static String nome;

    static class Versao{
        String versao;
    public void vr(){
        System.out.println("o nome do aplicativo "+nome);
        System.out.println("a versao "+versao);
    }
    }
}
class exxlas{
    static void main(String[] args) {

        Aplicativo.nome=Input.st("qual o nome do aplicativo ");
        Aplicativo.Versao av = new Aplicativo.Versao();
        av.versao=Input.st("qual a versao :");
        av.vr();
    }
}