package Atividades.Exercicio1;

import java.util.Scanner;

public class Aluno {
    private String  nome;
        private double nota;
    Aluno(String nome , double nota){
        this.nome=nome;
        this.nota=nota;
    }
    public void mostrarResultado(){
        System.out.println("nome = "+nome+" nota = "+nota);
    }
    @Override
    public String toString() {
        System.out.println("nome = "+nome+" nota = "+nota);
        return "nome = "+nome+" nota = "+nota;
    }

}
class EAluno{
    static void main(String[] args) {
        String l ;
        double n;
        System.out.println("Digiteo seu nome: ");
        l=new Scanner(System.in).nextLine();
        System.out.println("Digite a sua Nota: ");
        n=new Scanner(System.in).nextDouble();
        Aluno a= new Aluno(l,n);
        a.mostrarResultado();
    }
}
