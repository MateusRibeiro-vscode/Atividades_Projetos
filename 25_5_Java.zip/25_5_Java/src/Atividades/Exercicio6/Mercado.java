package Atividades.Exercicio6;

public class Mercado {
    private String nome;

    public Mercado(String nome) {
        this.nome = nome;
    }

    public void etiquetador(String titulo){
        class Etqueta{
            void exibertitulo(){
                System.out.println("o nome do mercado"+nome);
                System.out.println("o titulo e "+titulo);
            }
        }
        Etqueta e = new Etqueta();
        e.exibertitulo();
    }
}
class Exmercado{
   static Mercado m =new Mercado(Input.st("qual o nome do mercado"));

    static void main(String[] args) {
        m.etiquetador(Input.st("qual e o titulo "));

    }
}
