package Atividades.Exercicio6;

public class Somador {
    public void me(double n1,double n2){
        class Calculadora{
        void soma(){
            System.out.println(n1+n2);
        }

    }
    Calculadora c = new Calculadora();
        c.soma();
}
;

    }
   class exsoma{
      public static void main(String[] args) {
           Somador s = new Somador();
           s.me(Input.d("qual o primeiro numero "),Input.d("qual o segudo numero"));
       }
   }

