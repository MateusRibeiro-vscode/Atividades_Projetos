package Atividades.Exercicio8;

public enum CorSemaforo {
    VERDE,AMARELO,VERMELHO;
}
class eXcORS{
    static void main(String[] args) throws InterruptedException {
        for (int i = 0; i <25 ; i++) {
            Thread.sleep(1000);
            System.out.println(CorSemaforo.VERDE);
        }
        for (int i = 0; i <25 ; i++) {
            Thread.sleep(1000);
            System.out.println(CorSemaforo.AMARELO);
        }for (int i = 0; i <25 ; i++) {
            Thread.sleep(1000);
            System.out.println(CorSemaforo.VERMELHO);
        }

    }
}
