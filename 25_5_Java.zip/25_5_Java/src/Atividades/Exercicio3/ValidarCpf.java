package Atividades.Exercicio3;

import java.util.Scanner;

public final  class ValidarCpf {
     public void validar(String cpf){
         System.out.printf("esta validadando  o cpf %s",cpf);
    }

}
class testevalidar{
    public static void main(String[] args) {
        ValidarCpf vc = new ValidarCpf();
        System.out.println("qual o seu cpf ");
        Scanner s = new Scanner(System.in);
        String sa = s.nextLine();
        vc.validar(sa);
    }
}
