package Atividades.Exercicio10;

sealed public class Midia permits  LivroDigital,Video {
    void seila (){
        System.out.println("e uma midia");
    }
}
final class  LivroDigital extends Midia{
    @Override
    void seila (){
        System.out.println("e uma Livro digial");
    }
}
final class  Video extends Midia{
    @Override
    void seila (){
        System.out.println("e uma video");
    }
}
class ExMidia{
    static Midia v = new Video();

    static void main(String[] args) {
        v.seila();
    }
}
